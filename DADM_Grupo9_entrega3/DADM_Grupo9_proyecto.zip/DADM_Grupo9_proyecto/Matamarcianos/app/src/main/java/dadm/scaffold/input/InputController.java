package dadm.scaffold.input;

public class InputController {

    //region ||| Public properties |||

    public double horizontalFactor;
    public double verticalFactor;

    public boolean altFireMode = false;
    public boolean isFiring = true;

    //endregion

    //region ||| Public methods |||

    public void onStart() {
    }

    public void onStop() {
    }

    public void onPause() {
    }

    public void onResume() {
    }

    public void onPreUpdate() {
    }

    //endregion
}
